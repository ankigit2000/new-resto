﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.DTO
{
    public class RestaurantState
    {
        [Key]
        public Guid StateID { get; set; }
        public string StateName { get; set; }
        public int Zipcode { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
