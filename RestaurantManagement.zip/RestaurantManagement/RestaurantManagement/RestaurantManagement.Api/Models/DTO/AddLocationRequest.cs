﻿namespace RestaurantManagement.Api.Models.DTO
{
    public class AddLocationRequest
    {
        public string Address { get; set; }
        public Guid CityID { get; set; }
       // public RestaurantCity City { get; set; }
        public Guid StateID { get; set; }
        //public RestaurantState State { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
