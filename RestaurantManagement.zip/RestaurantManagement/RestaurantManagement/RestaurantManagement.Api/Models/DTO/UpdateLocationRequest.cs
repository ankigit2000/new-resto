﻿namespace RestaurantManagement.Api.Models.DTO
{
    public class UpdateLocationRequest
    {
        public string Address { get; set; }
        public Guid CityID { get; set; }
        public Guid StateID { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
