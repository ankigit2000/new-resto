﻿namespace RestaurantManagement.Api.Models.DTO
{
    public class UpdateRestaurantRequest
    {
        public string Restaurant { get; set; }
        public string Specialities { get; set; }
        public string AdditionalFeatures { get; set; }
    }
}
