﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantMenuItems
    {
        [Key]
        public Guid ItemID { get; set; }
        public string ItemName { get; set; }
        public string ItemType { get; set; }
        public Guid MenuTypeID { get; set; }
        public ResturantMenuType MenuType { get; set; }

    }
}
