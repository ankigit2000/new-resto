﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.Domains
{
    public class ResturantMenuType
    {
        [Key]
        public Guid MenuTypeID { get; set; }
        public string Breakfast { get; set; }
        public string Lunch { get; set; }
        public string Dinner { get; set; }
    }
}
