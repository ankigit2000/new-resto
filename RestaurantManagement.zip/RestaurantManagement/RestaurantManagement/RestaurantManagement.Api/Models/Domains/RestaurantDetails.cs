﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantDetails
    {
        [Key]
        public Guid RestaurantID { get; set; }
        public string Restaurant { get; set; }
        public string Specialities { get; set; }
        public string AdditionalFeatures { get; set; }

        [ForeignKey("Location")]
        public Guid LocationID { get; set; }
        public virtual RestaurantLocation Location { get; set; }

        [ForeignKey("Menu")]
        public Guid MenuID { get; set; }
        public virtual RestaurantMenu Menu { get; set; }

        [ForeignKey("Users")]
        public Guid UserID { get; set; }
        public virtual Users Users { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        
    }   
}
