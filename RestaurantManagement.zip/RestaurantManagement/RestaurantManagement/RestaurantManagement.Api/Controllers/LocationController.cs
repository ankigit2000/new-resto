﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RestaurantManagement.Api.Models.DTO;
using RestaurantManagement.Api.Repositories;

namespace RestaurantManagement.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LocationController : Controller
    {
        private readonly ILocationRepository locationRepository;
        private readonly IMapper mapper;

        public LocationController(ILocationRepository locationRepository, IMapper mapper)
        {
            this.locationRepository = locationRepository;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllLocationsAsync()
        {
            var locationDomain= await locationRepository.GetAllAsync();

            var locationDTO = mapper.Map<List<Models.DTO.RestaurantLocation>>(locationDomain);

                return Ok(locationDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetLocationAsync")]
        public async Task<IActionResult>GetLocationAsync(Guid id)
        {
            //get location domain object from database
           var locationDomain = await  locationRepository.GetAsync(id);

            //convert domain object to dto

            var locationDTO=mapper.Map<Models.DTO.RestaurantLocation>(locationDomain);
            //return response
            return Ok(locationDTO);
        }

        [HttpPost]
        public async Task<IActionResult> AddLocationAsync([FromBody] Models.DTO.AddLocationRequest addLocationRequest)
        {
            //convert dto to domain object
            var locationDomain = new Models.Domains.RestaurantLocation
            {
                Address = addLocationRequest.Address,
                CityID = addLocationRequest.CityID,
                StateID = addLocationRequest.StateID,
                UpdatedBy = addLocationRequest.UpdatedBy,
                UpdatedDate = addLocationRequest.UpdatedDate
            };
            //pass domain object to repository to persist this
             locationDomain = await locationRepository.AddAsync(locationDomain);
            //convert the domain object back to dto
            var locationDTO = new Models.DTO.RestaurantLocation
            {
                LocationID = locationDomain.LocationID,
                Address = locationDomain.Address,
                CityID = locationDomain.CityID,
                StateID = locationDomain.StateID,
                UpdatedBy = locationDomain.UpdatedBy,
                UpdatedDate = locationDomain.UpdatedDate
            };
            //send dto response back to client
            return CreatedAtAction(nameof(GetLocationAsync), new { id = locationDTO.LocationID }, locationDTO);
        }

        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdatedLocationAsync(Guid id, [FromBody] Models.DTO.UpdateLocationRequest updateLocationRequest)
        {
            var location = new Models.Domains.RestaurantLocation()
            {
                Address = updateLocationRequest.Address,
                CityID = updateLocationRequest.CityID,
                StateID = updateLocationRequest.StateID,
                UpdatedBy= updateLocationRequest.UpdatedBy,
                UpdatedDate = updateLocationRequest.UpdatedDate

            };


            // Update Region using repository
            location = await locationRepository.UpdateAsync(id, location);


            // If Null then NotFound
            if (location == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var locationDTO = new Models.DTO.RestaurantLocation()
            {
                LocationID = location.LocationID,
                Address = location.Address,
                CityID = location.CityID,
                StateID = location.StateID,
                UpdatedBy = location.UpdatedBy,
                UpdatedDate = location.UpdatedDate
            };


            // Return Ok response
            return Ok(locationDTO);
        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteLocationsAsync(Guid id)
        {
            //get locations from database
            var location = await locationRepository.DeleteAsync(id);

            //If null not found
            if (location == null)
            {
                return NotFound();
            }

            //convert response back to DTO
            var locationDTO=mapper.Map<Models.DTO.RestaurantLocation>(location);
            return Ok(locationDTO);
            
        }
    }
}
