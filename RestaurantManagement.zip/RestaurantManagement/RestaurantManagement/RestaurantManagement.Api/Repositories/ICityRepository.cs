﻿using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public interface ICityRepository
    {
        Task<IEnumerable<RestaurantCity>> GetAllAsync();
        Task<RestaurantCity> GetAsync(Guid id);

        Task<RestaurantCity> AddAsync(RestaurantCity city);

        Task<RestaurantCity> DeleteAsync(Guid id);

        Task<RestaurantCity> UpdateAsync(Guid id, RestaurantCity updated);
    }
}
