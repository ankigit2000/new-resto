﻿using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public interface IStateRepository
    {
        Task<IEnumerable<RestaurantState>> GetAllAsync();
        Task<RestaurantState> GetAsync(Guid id);

        Task<RestaurantState> AddAsync(RestaurantState state);

        Task<RestaurantState> DeleteAsync(Guid id);

        Task<RestaurantState> UpdateAsync(Guid id, RestaurantState updated);
      
    }
}
