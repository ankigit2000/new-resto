﻿using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Api.Data;
using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public class StateRepository: IStateRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public StateRepository(RestaurantDetailsDbContext restaurantDetailsDbContext)
        {
            this.restaurantDetailsDbContext = restaurantDetailsDbContext;
        }

        public async Task<RestaurantState> AddAsync(RestaurantState state)
        {
            state.StateID = Guid.NewGuid();
            await restaurantDetailsDbContext.AddAsync(state);
            await restaurantDetailsDbContext.SaveChangesAsync();
            return state;
        }

        public async Task<RestaurantState> DeleteAsync(Guid id)
        {
            var state = await restaurantDetailsDbContext.State.FirstOrDefaultAsync(x => x.StateID == id);
            if (state != null)
            {
                return null;
            }
            restaurantDetailsDbContext.State.Remove(state);
            await restaurantDetailsDbContext.SaveChangesAsync();
            return state;
        }

        public async Task<IEnumerable<RestaurantState>> GetAllAsync()
        {
            return await restaurantDetailsDbContext.State.ToListAsync();
        }

        public async Task<RestaurantState> GetAsync(Guid id)
        {
            return await restaurantDetailsDbContext.State.FirstOrDefaultAsync(x => x.StateID == id);


        }

        public async Task<RestaurantState> UpdateAsync(Guid id, RestaurantState updated)
        {
            var existingState = await restaurantDetailsDbContext.State.FirstOrDefaultAsync(x => x.StateID == id);
            if (existingState == null)
            {
                return null;
            }
            existingState.StateName = updated.StateName;
            existingState.Zipcode = updated.Zipcode;
            existingState.UpdatedBy = updated.UpdatedBy;
            existingState.UpdatedDate = updated.UpdatedDate;

            await restaurantDetailsDbContext.SaveChangesAsync();
            return updated;

        }
    }
}
