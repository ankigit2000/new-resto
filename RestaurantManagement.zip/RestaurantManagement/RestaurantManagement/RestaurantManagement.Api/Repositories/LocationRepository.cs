﻿using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Api.Data;
using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public class LocationRepository : ILocationRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public LocationRepository(RestaurantDetailsDbContext restaurantDetailsDbContext)
        {
            this.restaurantDetailsDbContext = restaurantDetailsDbContext;
        }

        public async Task<RestaurantLocation> AddAsync(RestaurantLocation location)
        {
            //assign New ID
            location.LocationID = Guid.NewGuid();
            await restaurantDetailsDbContext.Location.AddAsync(location);
            await restaurantDetailsDbContext.SaveChangesAsync();
            return location;
        }

        public async Task<IEnumerable<RestaurantLocation>> GetAllAsync()
        {
            return await restaurantDetailsDbContext.Location
                .Include(x => x.City)
                .Include(x => x.State)
                .ToListAsync();
        }

        public Task<RestaurantLocation> GetAsync(Guid id)
        {
            return restaurantDetailsDbContext.Location
                 .Include(x => x.City)
                 .Include(x => x.State)
                 .FirstOrDefaultAsync(x => x.LocationID == id);
        }
        public async Task<RestaurantLocation> UpdateAsync(Guid id, RestaurantLocation updated)
        {
            var existingLocation = await restaurantDetailsDbContext.Location.FindAsync(id);
            if (existingLocation == null)
            {
                return null;
            }
            existingLocation.Address = updated.Address;
            existingLocation.UpdatedBy = updated.UpdatedBy;
            existingLocation.UpdatedDate = updated.UpdatedDate;

            await restaurantDetailsDbContext.SaveChangesAsync();
            return updated;

        }

        public async Task<RestaurantLocation> DeleteAsync(Guid id)
        {
            var location = await restaurantDetailsDbContext.Location.FindAsync(id);
            if (location == null)
            {
                return null;
            }
            restaurantDetailsDbContext.Location.Remove(location);
            await restaurantDetailsDbContext.SaveChangesAsync();
            return location;

        }
    }
}
