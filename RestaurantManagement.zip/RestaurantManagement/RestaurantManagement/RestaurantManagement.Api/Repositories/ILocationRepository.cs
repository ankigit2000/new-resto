﻿using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public interface ILocationRepository
    {
        Task<IEnumerable<RestaurantLocation>> GetAllAsync();
        Task<RestaurantLocation> GetAsync(Guid id);
        Task<RestaurantLocation> AddAsync(RestaurantLocation location);
        Task<RestaurantLocation> UpdateAsync(Guid id, RestaurantLocation updated);
        Task<RestaurantLocation> DeleteAsync(Guid id);
    }
}
