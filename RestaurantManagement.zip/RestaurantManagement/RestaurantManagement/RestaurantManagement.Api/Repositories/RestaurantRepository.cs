﻿using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Api.Data;
using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public class RestaurantRepository : IRestaurantRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public RestaurantRepository(RestaurantDetailsDbContext restaurantDetailsDbContext) 
        {
            this.restaurantDetailsDbContext = restaurantDetailsDbContext;
        }

        public async Task<RestaurantDetails> AddAsync(RestaurantDetails restaurant)
        {
            restaurant.RestaurantID = Guid.NewGuid();
            await restaurantDetailsDbContext.AddAsync(restaurant);
            await restaurantDetailsDbContext.SaveChangesAsync();
            return restaurant;
        }

        public async Task<RestaurantDetails> DeleteAsync(Guid id)
        {
            var restaurant = await restaurantDetailsDbContext.RestaurantDetails.FirstOrDefaultAsync(x => x.RestaurantID == id);
            if (restaurant == null)
            {
                return null;
            }
            restaurantDetailsDbContext.RestaurantDetails.Remove(restaurant);
            await restaurantDetailsDbContext.SaveChangesAsync();
            return restaurant;
        }

        public async Task<IEnumerable<RestaurantDetails>> GetAllAsync()
        {
           return await restaurantDetailsDbContext.RestaurantDetails.ToListAsync();
        }

        public async Task<RestaurantDetails> GetAsync(Guid id)
        {
           return await restaurantDetailsDbContext.RestaurantDetails.FirstOrDefaultAsync(x  =>x.RestaurantID == id);
           
        }

        public async Task<RestaurantDetails> UpdateAsync(Guid id, RestaurantDetails updated)
        {
            var existingResturant = await restaurantDetailsDbContext.RestaurantDetails.FirstOrDefaultAsync(x => x.RestaurantID == id);
            if (existingResturant == null)
            {
                return null;
            }
            existingResturant.Restaurant = updated.Restaurant;
            existingResturant.Specialities = updated.Specialities;
            existingResturant.AdditionalFeatures = updated.AdditionalFeatures;

            await restaurantDetailsDbContext.SaveChangesAsync();
            return updated;

        }
    }
}
