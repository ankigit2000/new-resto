﻿using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Data
{
    public class RestaurantDetailsDbContext:DbContext
    {
        public RestaurantDetailsDbContext(DbContextOptions<RestaurantDetailsDbContext> options): base(options) 
        {

        }
        public DbSet<RestaurantDetails> RestaurantDetails { get; set; }
        public DbSet<RestaurantCity> City { get; set; }
        public DbSet<RestaurantState> State { get; set; }
        public DbSet<RestaurantLocation> Location { get; set; }
        public DbSet<RestaurantMenuItems> MenuItems { get; set; }
        public DbSet<ResturantMenuType> MenuType { get; set; }
        public DbSet<RestaurantMenu> Menu { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Users> Users { get; set; }
        
    }
}
