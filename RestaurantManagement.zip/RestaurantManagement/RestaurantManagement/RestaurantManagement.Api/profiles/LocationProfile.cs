﻿using AutoMapper;

namespace RestaurantManagement.Api.profiles
{
    public class LocationProfile:Profile
    {
        public LocationProfile()
        {
            CreateMap<Models.Domains.RestaurantLocation, Models.DTO.RestaurantLocation>()
                .ReverseMap();
        }
    }
}
