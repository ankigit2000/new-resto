﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RestaurantManagement.Api.Models.Domains;
using RestaurantManagement.Api.Models.DTO;
using RestaurantManagement.Api.Repositories;

namespace RestaurantManagement.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RestaurantController : Controller
    {
        private readonly IRestaurantRepository restaurantRepository;
        private readonly IMapper mapper;

        public RestaurantController(IRestaurantRepository restaurantRepository, IMapper mapper)
        {
            this.restaurantRepository = restaurantRepository;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllRestaurantsAsync()
        {
           var restaurants= await restaurantRepository.GetAllAsync();
            /* var restaurantsDTO = new List<Models.DTO.RestaurantDetails>();
             restaurants.ToList().ForEach(restaurant =>
             {
                 var restaurantDTO = new Models.DTO.RestaurantDetails()
                 {
                     RestaurantId=restaurant.RestaurantId,
                     Restaurant = restaurant.Restaurant,
                     Specialities = restaurant.Specialities,
                     AdditionalFeatures = restaurant.AdditionalFeatures,
                     UpdatedBy = restaurant.UpdatedBy,
                     UpdatedDate = restaurant.UpdatedDate,
                     LocationID = restaurant.LocationID,
                     MenuID = restaurant.MenuID,
                     UserID = restaurant.UserID
                 };
                 restaurantsDTO.Add(restaurantDTO);
             });*/

            var restaurantsDTO=mapper.Map<List<Models.DTO.RestaurantDetails>>(restaurants);
            return Ok(restaurantsDTO);
            
        }

        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetRestaurantsAsync")]
        public async Task<IActionResult>GetRestaurantsAsync(Guid id)
        {
          var restaurant= await restaurantRepository.GetAsync(id);

            if(restaurant==null)
            {
                return NotFound();
            }
           var restaurantDTO = mapper.Map<Models.DTO.RestaurantDetails>(restaurant);
            return Ok(restaurantDTO);
        }

        [HttpPost]
        public async Task<IActionResult>AddRestaurantsAsync(Models.DTO.AddRestaurantRequest addRestarantRequest)
        {
            //Request to Domain Model
            var restaurant = new Models.Domains.RestaurantDetails()
            {

                Restaurant = addRestarantRequest.Restaurant,
                Specialities = addRestarantRequest.Specialities,
                AdditionalFeatures = addRestarantRequest.AdditionalFeatures,
                LocationID = addRestarantRequest.LocationID,
                MenuID = addRestarantRequest.MenuID,
                UserID = addRestarantRequest.UserID,
                UpdatedBy = addRestarantRequest.UpdatedBy,
                UpdatedDate = addRestarantRequest.UpdatedDate
                
            };
            //pass details to Repository
             restaurant = await restaurantRepository.AddAsync(restaurant);
            //Convert back to DTO
            var restaurantDTO = new Models.DTO.RestaurantDetails
            {
                RestaurantID = restaurant.RestaurantID,
                Restaurant = restaurant.Restaurant,
                Specialities = restaurant.Specialities,
                AdditionalFeatures = restaurant.AdditionalFeatures,
                LocationID = restaurant.LocationID,
                MenuID = restaurant.MenuID,
                UserID = restaurant.UserID,
                UpdatedBy = restaurant.UpdatedBy,
                UpdatedDate = restaurant.UpdatedDate
                
            };
            return CreatedAtAction(nameof(GetRestaurantsAsync), new { id = restaurantDTO.RestaurantID }, restaurantDTO);

        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult>DeleteRestaurantsAsync(Guid id)
        {
            //get restaurants from database
            var restaurant = await restaurantRepository.DeleteAsync(id);

            //If null not found
            if(restaurant== null)
            {
                return NotFound();
            }

            //convert response back to DTO

            var restaurantDTO = new Models.DTO.RestaurantDetails
            {
                RestaurantID = restaurant.RestaurantID,
                Restaurant = restaurant.Restaurant,
                Specialities = restaurant.Specialities,
                AdditionalFeatures = restaurant.AdditionalFeatures,
                LocationID = restaurant.LocationID,
                MenuID = restaurant.MenuID,
                UserID = restaurant.UserID,
                UpdatedBy = restaurant.UpdatedBy,
                UpdatedDate = restaurant.UpdatedDate,
            };
            //return ok response
            return Ok(restaurantDTO);
        }

        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult>UpdatedRestaurantAsync(Guid id, [FromBody] Models.DTO.UpdateRestaurantRequest updateRestaurantRequest)
        {
            var restaurant = new Models.Domains.RestaurantDetails()
            {
                Restaurant = updateRestaurantRequest.Restaurant,
                Specialities = updateRestaurantRequest.Specialities,
                AdditionalFeatures = updateRestaurantRequest.AdditionalFeatures,

            };


            // Update Region using repository
             restaurant = await restaurantRepository.UpdateAsync(id, restaurant);


            // If Null then NotFound
            if (restaurant == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var restaurantDTO = new Models.DTO.RestaurantDetails()
            {
                RestaurantID = restaurant.RestaurantID,
                Restaurant = restaurant.Restaurant,
                Specialities = restaurant.Specialities,
                AdditionalFeatures = restaurant.AdditionalFeatures,
                LocationID = restaurant.LocationID,
                MenuID = restaurant.MenuID,
                UserID = restaurant.UserID,
                UpdatedBy = restaurant.UpdatedBy,
                UpdatedDate = restaurant.UpdatedDate,
            };


            // Return Ok response
            return Ok(restaurantDTO);
        }
    }
}
