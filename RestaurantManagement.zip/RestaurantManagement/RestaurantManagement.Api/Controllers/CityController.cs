﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RestaurantManagement.Api.Repositories;

namespace RestaurantManagement.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CityController : Controller
    {
        private readonly ICityRepository cityRepository;
        private readonly IMapper mapper;

        public CityController(ICityRepository cityRepository, IMapper mapper)
        {
            this.cityRepository = cityRepository;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllCitiesAsync()
        {
            var cities = await cityRepository.GetAllAsync();
            

            var citiesDTO = mapper.Map<List<Models.DTO.RestaurantCity>>(cities);
            return Ok(citiesDTO);

        }

        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetCitiesAsync")]
        public async Task<IActionResult> GetCitiesAsync(Guid id)
        {
            var city = await cityRepository.GetAsync(id);

            if (city == null)
            {
                return NotFound();
            }
            var cityDTO = mapper.Map<Models.DTO.RestaurantCity>(city);
            return Ok(cityDTO);
        }

        [HttpPost]
        public async Task<IActionResult> AddCitiesAsync(Models.DTO.AddCityRequest addCityRequest)
        {
            //Request to Domain Model
            var city = new Models.Domains.RestaurantCity()
            {

                CityName = addCityRequest.CityName,               
                UpdatedBy = addCityRequest.UpdatedBy,
                UpdatedDate = addCityRequest.UpdatedDate

            };
            //pass details to Repository
            city = await cityRepository.AddAsync(city);
            //Convert back to DTO
            var cityDTO = new Models.DTO.RestaurantCity
            {
                CityName = city.CityName,             
                UpdatedBy = city.UpdatedBy,
                UpdatedDate = city.UpdatedDate

            };
            return CreatedAtAction(nameof(GetCitiesAsync), new { id = cityDTO.CityID }, cityDTO);

        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteCitiesAsync(Guid id)
        {
            //get restaurants from database
            var city = await cityRepository.DeleteAsync(id);

            //If null not found
            if (city == null)
            {
                return NotFound();
            }

            //convert response back to DTO

            var cityDTO = new Models.DTO.RestaurantCity
            {
                CityID= city.CityID,
                CityName = city.CityName,
                UpdatedBy = city.UpdatedBy,
                UpdatedDate = city.UpdatedDate
            };
            //return ok response
            return Ok(cityDTO);
        }

        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdatedCityAsync(Guid id, [FromBody] Models.DTO.UpdateCityRequest updateCityRequest)
        {
            var city = new Models.Domains.RestaurantCity()
            {
                CityName = updateCityRequest.CityName,
                UpdatedBy = updateCityRequest.UpdatedBy,
                UpdatedDate = updateCityRequest.UpdatedDate

            };


            // Update Region using repository
            city = await cityRepository.UpdateAsync(id, city);


            // If Null then NotFound
            if (city == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var cityDTO = new Models.DTO.RestaurantCity()
            {
                CityID = city.CityID,
                CityName = city.CityName,
                UpdatedBy = city.UpdatedBy,
                UpdatedDate = city.UpdatedDate
            };


            // Return Ok response
            return Ok(cityDTO);
        }
    }
}
