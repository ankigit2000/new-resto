﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RestaurantManagement.Api.Repositories;

namespace RestaurantManagement.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StateController : Controller
    {
        private readonly IStateRepository stateRepository;
        private readonly IMapper mapper;

        public StateController(IStateRepository stateRepository, IMapper mapper)
        {
            this.stateRepository = stateRepository;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllStatesAsync()
        {
            var states = await stateRepository.GetAllAsync();


            var statesDTO = mapper.Map<List<Models.DTO.RestaurantState>>(states);
            return Ok(statesDTO);

        }

        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetCitiesAsync")]
        public async Task<IActionResult> GetStatesAsync(Guid id)
        {
            var state = await stateRepository.GetAsync(id);

            if (state == null)
            {
                return NotFound();
            }
            var stateDTO = mapper.Map<Models.DTO.RestaurantState>(state);
            return Ok(stateDTO);
        }

        [HttpPost]
        public async Task<IActionResult> AddStatesAsync(Models.DTO.AddStateRequest addStateRequest)
        {
            //Request to Domain Model
            var state = new Models.Domains.RestaurantState()
            {

                StateName = addStateRequest.StateName,
                Zipcode = addStateRequest.Zipcode,
                UpdatedBy = addStateRequest.UpdatedBy,
                UpdatedDate = addStateRequest.UpdatedDate

            };
            //pass details to Repository
            state = await stateRepository.AddAsync(state);
            //Convert back to DTO
            var stateDTO = new Models.DTO.RestaurantState
            {
                StateName = state.StateName,
                Zipcode = state.Zipcode,
                UpdatedBy = state.UpdatedBy,
                UpdatedDate = state.UpdatedDate

            };
            return CreatedAtAction(nameof(GetStatesAsync), new { id = stateDTO.StateID }, stateDTO);

        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteStatesAsync(Guid id)
        {
            //get restaurants from database
            var state = await stateRepository.DeleteAsync(id);

            //If null not found
            if (state == null)
            {
                return NotFound();
            }

            //convert response back to DTO

            var stateDTO = new Models.DTO.RestaurantState
            {
                StateID=state.StateID,
                StateName = state.StateName,
                Zipcode = state.Zipcode,
                UpdatedBy = state.UpdatedBy,
                UpdatedDate = state.UpdatedDate
            };
            //return ok response
            return Ok(stateDTO);
        }

        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdatedStateAsync(Guid id, [FromBody] Models.DTO.UpdateStateRequest updateStateRequest)
        {
            var state = new Models.Domains.RestaurantState()
            {
                StateName = updateStateRequest.StateName,
                Zipcode = updateStateRequest.Zipcode,
                UpdatedBy = updateStateRequest.UpdatedBy,
                UpdatedDate = updateStateRequest.UpdatedDate

            };


            // Update Region using repository
            state = await stateRepository.UpdateAsync(id, state);


            // If Null then NotFound
            if (state == null)
            {
                return NotFound();
            }

            // Convert Domain back to DTO
            var cityDTO = new Models.DTO.RestaurantState()
            {
                StateID = state.StateID,
                StateName = state.StateName,
                Zipcode = state.Zipcode,
                UpdatedBy = state.UpdatedBy,
                UpdatedDate = state.UpdatedDate
            };


            // Return Ok response
            return Ok(cityDTO);
        }
    }
}
