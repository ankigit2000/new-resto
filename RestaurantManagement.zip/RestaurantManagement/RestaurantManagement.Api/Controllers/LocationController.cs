﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using RestaurantManagement.Api.Repositories;

namespace RestaurantManagement.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LocationController : Controller
    {
        private readonly ILocationRepository locationRepository;
        private readonly IMapper mapper;

        public LocationController(ILocationRepository locationRepository, IMapper mapper)
        {
            this.locationRepository = locationRepository;
            this.mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllLocationsAsync()
        {
            var locationDomain= await locationRepository.GetAllAsync();

            var locationDTO = mapper.Map<List<Models.DTO.RestaurantLocation>>(locationDomain);

                return Ok(locationDTO);
        }
        [HttpGet]
        [Route("{id:guid}")]
        public async Task<IActionResult>GetLocationAsync(Guid id)
        {
            //get location domain object from database
           var locationDomain = await  locationRepository.GetAsync(id);

            //convert domain object to dto

            var locationDTO=mapper.Map<Models.DTO.RestaurantLocation>(locationDomain);
            //return response
            return Ok(locationDTO);
        }
    }
}
