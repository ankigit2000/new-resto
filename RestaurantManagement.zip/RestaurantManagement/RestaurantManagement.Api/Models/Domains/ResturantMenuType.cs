﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.Domains
{
    public class ResturantMenuType
    {
        [Key]
        public Guid MenuTypeID { get; set; }
        public Guid MenuType { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        public IEnumerable<RestaurantMenuItems> MenuItems { get; set; }
    }
}
