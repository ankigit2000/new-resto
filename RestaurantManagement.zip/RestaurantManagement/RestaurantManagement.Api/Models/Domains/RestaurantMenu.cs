﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantMenu
    {
        [Key]
        public Guid MenuID { get; set; }
        public Guid ItemID { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }


        public IEnumerable<RestaurantDetails> RestaurantMasterDetails { get; set; }
        public RestaurantMenuItems MenuItems { get; set; }
        
    }
}
