﻿namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantMenu
    {
        public Guid MenuID { get; set; }
        public Guid RestaurantID { get; set; }
        public string ItemName { get; set; }
        public float Price { get; set; }

        public RestaurantDetails RestaurantMasterDetails { get; set; }
    }
}
