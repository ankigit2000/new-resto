﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantMenu
    {
        [Key]
        public Guid MenuID { get; set; }
        public Guid ItemID { get; set; }
        public RestaurantMenuItems MenuItems { get; set; }

    }
}
