﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantMenuItems
    {
        [Key]
        public Guid ItemID { get; set; }
        public string ItemName { get; set; }
        public string ItemType { get; set; }
        public string MenuTypeID { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public IEnumerable<RestaurantMenu> RestaurantMenu { get; set; }
        public ResturantMenuType RestaurantMenuTypes { get; set; }
        
    }
}
