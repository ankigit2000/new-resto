﻿namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantLocation
    {
        public Guid LocationId { get; set; }
        public string City { get; set; }
        public string State { get; set; }

        public IEnumerable<RestaurantDetails> RestaurantMasterDetails { get; set; }

    }
}
