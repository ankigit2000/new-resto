﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantLocation
    {
        [Key]
        public Guid LocationId { get; set; }
        public string Address { get; set; }
        //public Guid CityID { get; set; }
        //public Guid StateID { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        public IEnumerable<RestaurantDetails> RestaurantMasterDetails { get; set; }

        [ForeignKey("City")]
        public Guid CityID { get; set; }
        public RestaurantCity City { get; set; }

        [ForeignKey("State")]
        public Guid StateID { get; set; }
        public RestaurantState State { get; set; }

    }
}
