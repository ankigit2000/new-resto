﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.Domains
{
    public class Users
    {
        [Key]
        public Guid UserID { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public Guid RoleID { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        public IEnumerable<RestaurantDetails> RestaurantMasterDetails { get; set; }
        public Role Roles { get; set; }

    }
}
