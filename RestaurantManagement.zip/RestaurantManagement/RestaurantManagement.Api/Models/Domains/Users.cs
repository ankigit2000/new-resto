﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantManagement.Api.Models.Domains
{
    public class Users
    {
        [Key]
        public Guid UserID { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public Guid RoleID { get; set; }
        public Role Role { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }


    }
}
