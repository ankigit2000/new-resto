﻿namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantDetails
    {
        public Guid RestaurantId { get; set; }
        public string Name { get; set; }
        public  string Specialities { get; set; }
        public string AdditionalFeatures { get; set; }
        public Guid LocationId { get; set; }
        public Guid OwnerId { get; set; }

        public IEnumerable<RestaurantMenu> Menu { get; set; }

        public RestaurantLocation RestaurantLocations { get; set; }
        public RestaurantOwner RestaurantOwners { get; set; }
    }
}
