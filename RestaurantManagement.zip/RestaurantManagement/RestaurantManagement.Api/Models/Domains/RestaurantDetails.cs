﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.Domains
{
    public class RestaurantDetails
    {
        [Key]
        public Guid RestaurantId { get; set; }
        public string Name { get; set; }
        public  string Specialities { get; set; }
        public string AdditionalFeatures { get; set; }
        public Guid LocationID { get; set; }
        public Guid MenuId { get; set; }
        public Guid UserId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public RestaurantLocation RestaurantLocations { get; set; }
        public RestaurantMenu RestaurantMenuList { get; set; }
        public Users Users { get; set; }
    }
}
