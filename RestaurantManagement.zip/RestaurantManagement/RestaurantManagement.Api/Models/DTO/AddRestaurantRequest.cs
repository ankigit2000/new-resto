﻿using RestaurantManagement.Api.Models.Domains;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantManagement.Api.Models.DTO
{
    public class AddRestaurantRequest
    {

        public string Restaurant { get; set; }
        public string Specialities { get; set; }
        public string AdditionalFeatures { get; set; }

        [ForeignKey("Location")]
        public Guid LocationID { get; set; }
        public virtual RestaurantLocation Location { get; set; }

        [ForeignKey("Menu")]
        public Guid MenuID { get; set; }
        public virtual RestaurantMenu Menu { get; set; }

        [ForeignKey("User")]
        public Guid UserID { get; set; }
        public virtual Users User { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
