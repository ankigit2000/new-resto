﻿namespace RestaurantManagement.Api.Models.DTO
{
    public class AddStateRequest
    {
        public string StateName { get; set; }
        public int Zipcode { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
