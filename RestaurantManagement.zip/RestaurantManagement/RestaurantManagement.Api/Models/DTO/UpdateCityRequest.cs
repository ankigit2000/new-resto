﻿namespace RestaurantManagement.Api.Models.DTO
{
    public class UpdateCityRequest
    {
        public string CityName { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
