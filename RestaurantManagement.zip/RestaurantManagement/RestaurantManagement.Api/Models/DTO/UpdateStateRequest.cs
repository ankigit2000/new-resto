﻿namespace RestaurantManagement.Api.Models.DTO
{
    public class UpdateStateRequest
    {
        public string StateName { get; set; }
        public int Zipcode { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
