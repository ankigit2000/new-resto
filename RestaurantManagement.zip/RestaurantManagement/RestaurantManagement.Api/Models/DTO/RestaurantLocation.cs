﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.DTO
{
    public class RestaurantLocation
    {
        [Key]
        public Guid LocationID { get; set; }
        public string Address { get; set; }
        public Guid CityID { get; set; }
        public RestaurantCity City { get; set; }
        public Guid StateID { get; set; }
        public RestaurantState State { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
