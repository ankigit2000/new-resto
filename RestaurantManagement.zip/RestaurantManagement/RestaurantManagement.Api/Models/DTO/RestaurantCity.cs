﻿using System.ComponentModel.DataAnnotations;

namespace RestaurantManagement.Api.Models.DTO
{
    public class RestaurantCity
    {
        [Key]
        public Guid CityID { get; set; }
        public string CityName { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
