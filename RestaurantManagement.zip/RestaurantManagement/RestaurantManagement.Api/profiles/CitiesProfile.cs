﻿using AutoMapper;

namespace RestaurantManagement.Api.profiles
{
    public class CitiesProfile:Profile
    {
        public CitiesProfile()
        {
            CreateMap<Models.Domains.RestaurantCity, Models.DTO.RestaurantCity>()
                .ReverseMap();
            //.ForMember(dest => dest.CityID, options => options.MapFrom(src => src.CityID));
        }
    }
}
