﻿using AutoMapper;

namespace RestaurantManagement.Api.profiles
{
    public class StateProfile:Profile
    {
        public StateProfile()
        {
            CreateMap<Models.Domains.RestaurantCity, Models.DTO.RestaurantCity>()
                .ReverseMap();
           
        }
    }
}
