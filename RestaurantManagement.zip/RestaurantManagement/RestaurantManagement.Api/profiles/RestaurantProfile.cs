﻿using AutoMapper;

namespace RestaurantManagement.Api.profiles
{
    public class RestaurantProfile:Profile
    {
        public RestaurantProfile()
        {
            CreateMap<Models.Domains.RestaurantDetails, Models.DTO.RestaurantDetails>()
                .ReverseMap();
                //.ForMember(dest => dest.RestaurantId, options => options.MapFrom(src => src.RestaurantId));
        }
    }
}
