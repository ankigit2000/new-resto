﻿using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Api.Data;
using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public class CityRepository : ICityRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public CityRepository(RestaurantDetailsDbContext restaurantDetailsDbContext)
        {
            this.restaurantDetailsDbContext = restaurantDetailsDbContext;
        }

        public async Task<RestaurantCity> AddAsync(RestaurantCity city)
        {
            city.CityID = Guid.NewGuid();
            await restaurantDetailsDbContext.AddAsync(city);
            await restaurantDetailsDbContext.SaveChangesAsync();
            return city;
        }

        public async Task<RestaurantCity> DeleteAsync(Guid id)
        {
            var city = await restaurantDetailsDbContext.City.FirstOrDefaultAsync(x => x.CityID == id);
            if (city != null)
            {
                return null;
            }
            restaurantDetailsDbContext.City.Remove(city);
            await restaurantDetailsDbContext.SaveChangesAsync();
            return city;
        }

        public async Task<IEnumerable<RestaurantCity>> GetAllAsync()
        {
            return await restaurantDetailsDbContext.City.ToListAsync();
        }

        public async Task<RestaurantCity> GetAsync(Guid id)
        {
               return await restaurantDetailsDbContext.City.FirstOrDefaultAsync(x => x.CityID == id);
           

        }

        public async Task<RestaurantCity> UpdateAsync(Guid id, RestaurantCity updated)
        {
            var existingCity = await restaurantDetailsDbContext.City.FirstOrDefaultAsync(x => x.CityID == id);
            if (existingCity == null)
            {
                return null;
            }
            existingCity.CityName = updated.CityName;
            existingCity.UpdatedBy = updated.UpdatedBy;
            existingCity.UpdatedDate = updated.UpdatedDate;

            await restaurantDetailsDbContext.SaveChangesAsync();
            return updated;

        }
    }
}
