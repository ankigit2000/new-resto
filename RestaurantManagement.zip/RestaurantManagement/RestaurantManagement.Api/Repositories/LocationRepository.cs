﻿using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Api.Data;
using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public class LocationRepository:ILocationRepository
    {
        private readonly RestaurantDetailsDbContext restaurantDetailsDbContext;

        public LocationRepository(RestaurantDetailsDbContext restaurantDetailsDbContext)
        {
            this.restaurantDetailsDbContext = restaurantDetailsDbContext;
        }
        public async Task<IEnumerable<RestaurantLocation>> GetAllAsync()
        {
            return await restaurantDetailsDbContext.Location
                .Include(x => x.City)
                .Include(x => x.State)
                .ToListAsync();
        }

        public Task<RestaurantLocation> GetAsync(Guid id)
        {
           return restaurantDetailsDbContext.Location
                .Include(x => x.City)
                .Include(x => x.State)
                .FirstOrDefaultAsync(x => x.LocationID == id);
        }
    }
}
