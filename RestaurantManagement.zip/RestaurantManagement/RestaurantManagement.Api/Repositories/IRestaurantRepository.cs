﻿using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public interface IRestaurantRepository
    {
       Task<IEnumerable<RestaurantDetails>> GetAllAsync();
       Task<RestaurantDetails> GetAsync(Guid id);

        Task<RestaurantDetails> AddAsync(RestaurantDetails restaurant);

        Task<RestaurantDetails>DeleteAsync(Guid id);

        Task<RestaurantDetails> UpdateAsync(Guid id, RestaurantDetails updated);
    }
}
