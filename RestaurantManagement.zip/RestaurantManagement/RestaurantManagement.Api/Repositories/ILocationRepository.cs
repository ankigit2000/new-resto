﻿using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Repositories
{
    public interface ILocationRepository
    {
        Task<IEnumerable<RestaurantLocation>> GetAllAsync();
        Task<RestaurantLocation> GetAsync(Guid id);
    }
}
