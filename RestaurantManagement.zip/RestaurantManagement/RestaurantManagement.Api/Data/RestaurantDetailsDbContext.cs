﻿using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Api.Models.Domains;

namespace RestaurantManagement.Api.Data
{
    public class RestaurantDetailsDbContext:DbContext
    {
        public RestaurantDetailsDbContext(DbContextOptions<RestaurantDetailsDbContext> options): base(options) 
        {

        }
        public DbSet<RestaurantDetails> RestaurantMasterDetails { get; set; }
        public DbSet<RestaurantLocation> RestaurantLocation { get; set; }
        public DbSet<RestaurantMenu> RestaurantMenuList { get; set; } 
        public DbSet<RestaurantOwner> RestaurantOwners { get; set; }
        
    }
}
